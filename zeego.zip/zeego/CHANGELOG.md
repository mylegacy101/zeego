version: 5.0.0

1. update all packages at latest
2. add new product card
3. fix some previous issues
